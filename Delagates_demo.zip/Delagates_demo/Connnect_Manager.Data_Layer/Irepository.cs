﻿using Connect_Manager_Common_Layer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Connnect_Manager.Data_Layer
{
    public interface Irepository
    {
        void Save(Contact contact);
        void UpdateContactById(Contact contact,int id);
        void DeleteContactById(int id);
        List<Contact> GetAllContact();
        Contact GetContactById(int id);

    }
}
