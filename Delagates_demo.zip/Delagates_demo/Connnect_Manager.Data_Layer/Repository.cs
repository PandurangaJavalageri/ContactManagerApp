﻿using Connect_Manager_Common_Layer;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Connnect_Manager.Data_Layer
{
    public class Repository : Irepository
    {
        private readonly string file = "contactfile.txt";
        
        public void DeleteContactById(int id)
        {

            List<Contact> c = GetAllContact();
            File.WriteAllText(file, string.Empty);
            using (StreamWriter wr = new StreamWriter(file))
            {
                foreach (Contact item in c)
                {
                    Contact contact1;
                    if (item.ContactId != id)
                    { 
                        contact1 = item;
                        string contactCsv = $"{contact1.ContactId},{contact1.Name},{contact1.Mobile},{contact1.Email},{contact1.Location},{contact1.Address}";
                        wr.WriteLine(contactCsv);

                    }
                }
            }

            
            
        }

        public List<Contact> GetAllContact()
        {
            List<Contact> contacts = new List<Contact>();
            
            using(StreamReader sr=new StreamReader(file))
            {
                while (!sr.EndOfStream)
                {
                    string l = sr.ReadLine();
                    string[] values = l.Split(',');
                    Contact contact = new Contact();
                    contact.Name = values[1];
                    contact.Email = values[3];
                    contact.Address = values[5];
                    contact.ContactId = int.Parse(values[0]);
                    contact.Location = values[4];
                    contact.Mobile = values[2];
                    contacts.Add(contact);
                }
            }
            Console.WriteLine();
            return contacts;

        }

        public Contact GetContactById(int id)
        {
            using (StreamReader sr = new StreamReader(file))
            {
                while (!sr.EndOfStream)
                {
                    string l = sr.ReadLine();
                    string[] val = l.Split(',');
                    if (int.Parse(val[0]) == id)
                    {
                        string [] values= l.Split(',');
                        Contact contact = new Contact();
                        contact.Name = values[1];
                        contact.Email = values[3];
                        contact.Address = values[5];
                        contact.ContactId = int.Parse(values[0]);
                        contact.Location = values[4];
                        contact.Mobile = values[2];
                        return contact;
                    }
                }
            }
            Console.WriteLine();
            return null;
        }

        public void Save(Contact contact)
        {
            using (StreamWriter writer = new StreamWriter(file,true))
            {
                // contact => CSV    111,ramesh,ramesh@gmai.com,23434234,bangalore
                string contactCsv = $"{contact.ContactId},{contact.Name},{contact.Mobile},{contact.Email},{contact.Location},{contact.Address}";

                writer.WriteLine(contactCsv);
            }
        }

        public void UpdateContactById(Contact contact, int id)
        {
            
            List<Contact> c = GetAllContact();
            File.WriteAllText(file, string.Empty);
            using (StreamWriter wr = new StreamWriter(file))
            {
                foreach (var item in c)
                {
                    Contact contact1;
                    if (item.ContactId != id)
                    {
                        contact1 = item;
                        string contactCsv = $"{contact1.ContactId},{contact1.Name},{contact1.Mobile},{contact1.Email},{contact1.Location},{contact1.Address}";
                        wr.WriteLine(contactCsv);

                    }
                    else
                    {
                        contact1 = contact;
                        string contactCsv = $"{contact.ContactId},{contact.Name},{contact.Mobile},{contact.Email},{contact.Location},{contact.Address}";
                        wr.WriteLine(contactCsv);

                    }
                }
            }

            
                
               
                
            
        }
    }
}
