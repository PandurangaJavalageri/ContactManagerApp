﻿using ContactManager.Common_Layer;
using ContactManager.datalayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactManager.ConsoleApp
{
    internal class Program
    {
       private static IContactsRepository repository = new ContatctsFileRepository();

        static void Main(string[] args)
        {
            
            while (true)
            {
                Console.WriteLine("contact Manager");
                Console.WriteLine("-----------");
                Console.WriteLine("1.Create contact");
                Console.WriteLine("2.Get All Contact");
                Console.WriteLine("3.Get ContactById");
                Console.WriteLine("4.Edit Contact");
                Console.WriteLine("5.Delete Contatcts");
                Console.WriteLine("6.Exit");
                Console.WriteLine("--------");
                Console.WriteLine("enter your choice [1-0]:");
                int choice=int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1: CreateContact();
                        break;
                    case 2:GetAllContact();
                        break;
                    case 3:GetContactById();
                        break;
                    case 4:EditContact();
                        break;
                    case 5:DeleteContacts();
                        break;
                    case 6:Environment.Exit(0);
                        break;
                    default:break;

                }
            }


        }

        private static void DeleteContacts()
        {
            throw new NotImplementedException();
        }

        private static void EditContact()
        {
            throw new NotImplementedException();
        }

        private static void GetAllContact()
        {
            List<Contact> list = repository.GetAllContacts();
            foreach (Contact contact in list)
            {
                Console.WriteLine(contact);
            }
        }

        private static void GetContactById()
        {
            Console.WriteLine("enter the contatct id");
            int id=int.Parse(Console.ReadLine());
            Console.WriteLine(repository.GetContactById( id));
        }

       

        private static void CreateContact()
        {
            Contact c1 = new Contact();
            Console.WriteLine("ContactId:");
            c1.ContactId = int.Parse(Console.ReadLine());
            Console.WriteLine("enter name");
            c1.Name = Console.ReadLine();
            Console.WriteLine("enter mobile");
            c1.Mobile = Console.ReadLine();
            Console.WriteLine("enter location");
            c1.Location = Console.ReadLine();
            Console.WriteLine("enter email");
            c1.Email = Console.ReadLine();
          
            repository.Save(c1);
            Console.WriteLine("contacts saved successfully");
        }
    }
}
