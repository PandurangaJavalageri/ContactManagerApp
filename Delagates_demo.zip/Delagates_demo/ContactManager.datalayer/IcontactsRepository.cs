﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ContactManager.Common_Layer;
using System.Threading.Tasks;

namespace ContactManager.datalayer
{
    public interface IContactsRepository
    {
         void Save(Contact contact);
        List<Contact>GetAllContacts();

        Contact GetContactById(int id);
        void DeleteContactById(int id);
        void UpdateContactById(Contact contact, int contactID);
    }
}
