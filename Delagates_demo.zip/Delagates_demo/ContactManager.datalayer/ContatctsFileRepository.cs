﻿using ContactManager.Common_Layer;
using System;
using System.Collections.Generic;
using System.IO;
namespace ContactManager.datalayer
{

    public class ContatctsFileRepository : IContactsRepository
    {
        private readonly string file = "contacts.txt";
        public void DeleteContactById(int id)
        {
            throw new NotImplementedException();
        }

        public List<Contact> GetAllContacts()
        {
            StreamReader sr;
            return null;
            

        }

        public Contact GetContactById(int id)
        {
            throw new NotImplementedException();
        }

        public void Save(Contact contact)
        {

            using (StreamWriter writer = new StreamWriter(file,true))
            {
                string contactCsv = $"{contact.ContactId},{contact.Name},{contact.Mobile},{contact.Email},{contact.Location}";

                writer.WriteLine(contactCsv);
            }
        }

        

        public void UpdateContactById(Contact contact, int contactID)
        {
            throw new NotImplementedException();
        }

       
    }
}
