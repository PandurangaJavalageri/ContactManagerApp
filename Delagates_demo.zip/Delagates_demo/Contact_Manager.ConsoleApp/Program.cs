﻿using Connect_Manager_Common_Layer;
using Connnect_Manager.Data_Layer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contact_Manager.ConsoleApp
{
    internal class Program
    {
        static Irepository repository = new Repository();
        static void Main(string[] args)
        {
            

            while (true)
            {
                Console.WriteLine("Contact Manager");
                Console.WriteLine("=====================");
                Console.WriteLine("1. Create Contact");
                Console.WriteLine("2. Get All Contacts");
                Console.WriteLine("3. Get Contact By ID");
                Console.WriteLine("4. Edit Contact");
                Console.WriteLine("5. Delete Contact");
                Console.WriteLine("6. Exit");
                Console.WriteLine("----------------------");
                Console.Write("Enter your choice [1-6] :");
                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1: CreateContact(); break;
                    case 2: GetAllContacts(); break;
                    case 3: GetContactById(); break;
                    case 4: EditContact(); break;
                    case 5: DeleteContact(); break;
                    case 6: Environment.Exit(0); break;
                    default: Console.WriteLine("Invalid option"); break;
                }

            }

        }

        private static void DeleteContact()
        {
            Console.WriteLine("enter the id");
            int id=int.Parse(Console.ReadLine());   
            repository.DeleteContactById(id);
        }

        private static void EditContact()
        {
            Contact c = new Contact();
            Console.WriteLine("enter Name");
            c.Name = Console.ReadLine();
            Console.WriteLine("enter ID");
            c.ContactId = int.Parse(Console.ReadLine());
            Console.WriteLine("enter address");
            c.Address = Console.ReadLine();
            Console.WriteLine("enter email");
            c.Email = Console.ReadLine();
            Console.WriteLine("enter location");
            c.Location = Console.ReadLine();
             repository.UpdateContactById(c,c.ContactId);
        }

        private static void GetContactById()
        {
            Console.WriteLine("enter the id");
            int n=int.Parse(Console.ReadLine());
            Contact c= repository.GetContactById(n);
            if(c!= null)
                Console.WriteLine(c.Name);
            Console.WriteLine();
        }

        private static void GetAllContacts()
        {
            List<Contact> contacts = repository.GetAllContact();
            foreach(var item in contacts)
            {
                Console.WriteLine(item.Name);
                Console.WriteLine(item.ContactId);
                Console.WriteLine(item.Address);
                Console.WriteLine(item.Mobile);
                Console.WriteLine(item.Email);
                Console.WriteLine(item.Location);
            }
            Console.WriteLine();
        }

        private static void CreateContact()
        {
            Contact c = new Contact();
            Console.WriteLine("enter Name");
            c.Name = Console.ReadLine();
            Console.WriteLine("enter ID");
            c.ContactId = int.Parse(Console.ReadLine());
            Console.WriteLine("enter address");
            c.Address = Console.ReadLine();
            Console.WriteLine("enter email");
            c.Email = Console.ReadLine();
            Console.WriteLine("enter location");
            c.Location = Console.ReadLine();
            Console.WriteLine("enter mobile");
            c.Mobile = Console.ReadLine();

            repository.Save(c);
        }
    }
}
