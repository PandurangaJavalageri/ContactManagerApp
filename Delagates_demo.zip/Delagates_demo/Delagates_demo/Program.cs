﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delagates_demo
{
    public delegate void MyDelegate(string msg);
    internal class Program
    {
        static void Main(string[] args)
        {
            //direct method invocation
            //method name:Greeting
            //signature of method (string str,return type:void)
            //type of method (static,instance)
            //class name:program
            //namespace:Delegates_demo
            //assembly:Delegates_demo
            //indirect method :call by it's address

      
            MyDelegate del = new MyDelegate(Greeting);
            
            
            Program p= new Program();
            //adding method to delegate
            del+=p.hi;//subscription
            //invoking all method from delegate
            del("hello");
            //removing a method from delegate
            del-=p.hi;//unsubscription
            del("hi");



        }
        static void Greeting(string msg)
        {
            Console.WriteLine($"greeting:{msg}");
        }
        public void hi(string msg)
        {
            Console.WriteLine(msg);
        }
        
    }
    //public class MyDelegate : Delegate
    //{

    //}
   //step 1:delegate declaration

    //step2:Institiation and intialize
   
}
