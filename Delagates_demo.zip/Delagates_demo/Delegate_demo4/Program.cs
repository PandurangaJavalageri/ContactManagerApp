﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace Delegate_demo4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Account account = new Account();
            account.Notify += Notification.SendSMS;
            account.Notify += Notification.SendMail;
            account.Notify += Notification.SendWhats;
            //due to event driven delegatef
            //account.Notify("hrllo");
            
            account.Deposit(1000);
            Console.WriteLine(account.Balance);
            account.WithDraw(500);
            Console.WriteLine(account.Balance);
        }
    }
    class Account
    {
        public int Balance { get; set; }
        public event NotifyDelegates Notify = null;
        /*new NotifyDelegates(Notification.SendMail);*/

        public void Deposit(int amount)
        {
            Balance += amount;
            Console.WriteLine("Deposited");
            /*send email notification
            SmtpClient client = new SmtpClient();
            client.Port = 465;
            client.Host = "smtp.gmail.com";
            client.Credentials = null;//userid and password
            MailMessage message = new MailMessage("fromaddress", "toaddress");
            message.Bcc = "";
            message.Subject = "";
            message.Body = "";
            message.Attachments.Add("");
            client.Send(message);*/
            string msg = $"{amount} is deposited";
            /*Notification.SendMail(msg);
            Notification.SendSMS(msg);*/
            if(Notify!=null)
            Notify(msg);



        }
        public void WithDraw(int amount)
        {
            Balance -= amount;
            //Console.WriteLine("withdrawal");
            string msg = $"{amount} is withdraw";
            if (Notify != null)
                Notify(msg);
        }
    }
    public delegate void NotifyDelegates(string str);

    public class Notification
    {
        public static void SendMail(string message)
        {
            SmtpClient client = new SmtpClient();
            client.DeliveryMethod = SmtpDeliveryMethod.SpecifiedPickupDirectory;
            client.PickupDirectoryLocation = "C:\\Users\\PANDURANGA\\Desktop\\mails";
            MailMessage message1 = new MailMessage("abc@gmail.com","customer@gmail.com");
            message1.Body = "msg";
            client.Send(message1);

        }
        public static void SendSMS(string msg)
        {
            Console.WriteLine($"Sms:{msg}");
        }
        public static void SendWhats(string msg)
        {
            Console.WriteLine($"whats app {msg}");
        }
    }
}
