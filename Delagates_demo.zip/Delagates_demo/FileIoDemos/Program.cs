﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileIoDemos
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string readAllLines;
            using (StreamReader reader = new StreamReader("C:\\Users\\PANDURANGA\\Desktop\\demo\\names.txt")) 
            {
                readAllLines = reader.ReadToEnd();
            }
            Console.WriteLine(readAllLines);
            string readLine;
            Console.WriteLine();
            Console.WriteLine();
           using (StreamReader reader = new StreamReader("C:\\Users\\PANDURANGA\\Desktop\\demo\\names.txt"))
            {
                while(!reader.EndOfStream)
                {
                    readLine = reader.ReadLine();
                    Console.WriteLine(readLine);
                }
                
            }




        }
        public static void writedata()
        {
            StreamWriter writer = null;

            Console.WriteLine("enter person name");
            string name = Console.ReadLine();

            writer = new StreamWriter("C:\\Users\\PANDURANGA\\Desktop\\demo\\names.txt", true);
            writer.WriteLine(name);
            using (writer)
            {
                writer.WriteLine(name);
            }
        }
    }
}
