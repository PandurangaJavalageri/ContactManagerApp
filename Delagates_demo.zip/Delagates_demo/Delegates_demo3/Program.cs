﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates_demo3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> list = new List<int>() { 1, 2, 3, 4, 5 };
            int sum=list.Sum();
            //find all even numbersum
            Func<int, bool> filter = new Func<int, bool>(Iseven);

            int evensum = list.Where(filter).Sum();
            int evensum2=list.Where(Iseven).Sum();
            int evensum3=list.Where(delegate (int x)
            {
                return x % 2 == 0;
            }).Sum();
            
            int evensum5=list.Where((int x)=> x % 2 == 0).Sum();
            int evensum4=list.Where(x=>x%2== 0).Sum();


            //
        }
        public static bool Iseven(int x)
        {
            return x % 2 == 0;
        }
    }
}
