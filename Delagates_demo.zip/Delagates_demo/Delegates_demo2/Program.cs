﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates_demo2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //client 1 requirement is diaplay all process
            //ProcessManager.ShowProcessList();

            //client 2 display all process names starts with some alphabet
            /*  FilterDelegate f=new FilterDelegate(Program.filterByName);
              ProcessManager.ShowProcessList(f);*/

            //anonymous delegates
            /*ProcessManager.ShowProcessList(delegate(Process p)
            { return p.WorkingSet64 >= 100 * 1024 * 1024; });
*/

            //lambda:light weight syntax for anonymous delegates
            //lambda statements:not light weight/Expression:light weight
            //below method is called arrow function,goes to in c#


            //below writeen code is lambda statement
            /*ProcessManager.ShowProcessList( (Process p)=>
            { return p.WorkingSet64 >= 100 * 1024 * 1024; });*/


            //below code is lambda expression
            ProcessManager.ShowProcessList((Process p) =>
              p.WorkingSet64 >= 100 * 1024 * 1024);

            //type inference

            ProcessManager.ShowProcessList(p =>p.WorkingSet64 >= 100 * 1024 * 1024);


            //client 3 display all large processes


            //ProcessManager.ShowProcessList(filterByName);
        }
        /*public static bool filterBysize(Process p)
        {
            return p.WorkingSet64 >= 100 * 1024 * 1024;
        }*/
        /*public static bool filterByName(Process p)
        {
            return p.ProcessName.StartsWith("a");
        }*/
    }

    //declare a delegate
    public delegate  bool FilterDelegate(Process p);
    public class ProcessManager
    {
        
        public static void ShowProcessList(FilterDelegate filter)
        {
            foreach (Process p in Process.GetProcesses())
            {
                if (filter(p))
                    Console.WriteLine(p.ProcessName);
            }
        }
    }
}
